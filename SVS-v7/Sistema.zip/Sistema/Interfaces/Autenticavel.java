package Sistema.Interfaces;

public interface Autenticavel {

    void setSenha(String senha);

}
