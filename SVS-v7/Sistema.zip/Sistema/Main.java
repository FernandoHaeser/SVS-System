package Sistema;

import Sistema.View.MenuInicial;

public class Main {

    public void main(String[] args) {

        MenuInicial m = new MenuInicial();

        m.telaInicial(); // Tela inicial que inicia todo o sistema, indo para o Menu Inicial de Opções para o usuário.

    }
}

